
  HadCM3 - kml files
  ==================


  kml files are used within Google� Earth. The kml files provided with the CCWorldWeatherGen tool can
  be used for displaying the Met Office Hadley Centre HadCM3 grid coordinates with Google� Earth. The 
  following files are provided:


  (a)   HadCM3_grid_edge.kml => to display the grid edges of the 96x73 HadCM3 grid for all data
	parameters apart form wind speed

  (b)   HadCM3_grid_centre.kml => to display the grid centres of the 96x73 HadCM3 grid for all data
	parameters apart form wind speed

  (c)   HadCM3_grid_WIND_edge.kml => to display the grid edges of the 96x72 HadCM3 grid for wind speed

  (d)   HadCM3_grid_WIND_centre.kml => to display the grid centres of the 96x72 HadCM3 grid for wind speed